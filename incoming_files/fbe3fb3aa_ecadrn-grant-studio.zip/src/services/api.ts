export interface AIResponse<T = any> {
  data: T;
  error?: string;
}

export async function callAI<T = any>(action: string, data: any): Promise<T> {
  const response = await fetch(`/api/ai/${action}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'AI request failed');
  }

  return response.json();
}
